## [0.4.1]

- Bump flutter_bluetooth_basic to ^0.1.7

## [0.4.0]

- Bump esc_pos_utils to ^1.1.0. Using Generator instead of Ticket

## [0.3.0]

- Null-Safety

## [0.2.8]

- Bump esc_pos_utils

## [0.2.7]

- Updated flutter_bluetooth_basic

## [0.2.6]

- Updated flutter_bluetooth_basic

## [0.2.5]

- Split data into chunks

## [0.2.4]

- `startScan` timeout bug fixed.
- Updated `esc_pos_utils` package version to `0.3.4`.

## [0.2.3]

- Updated `esc_pos_utils` package version to `0.3.3`.

## [0.2.2]

- Updated `esc_pos_utils` package version to `0.3.2`.

## [0.2.1]

- Updated `esc_pos_utils` package version to `0.3.1` (Open Cash Drawer).

## [0.2.0]

- Updated `esc_pos_utils` package version to `0.3.0` (Image and Barcode alignment).

## [0.1.1]

- Updated `esc_pos_utils`, `flutter_bluetooth_basic` package versions

## [0.1.0]

- Android and iOS Bluetooth printing support
